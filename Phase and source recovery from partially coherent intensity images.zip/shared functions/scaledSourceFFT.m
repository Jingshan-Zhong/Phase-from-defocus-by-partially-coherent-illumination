function Source_fft_Nstack=scaledSourceFFT(nx,ny,ps,ps_source,Ampl_source,z)

%return the Fourier transform of scaled Ampl_source
%Source_fft_Nstack has size of (nx,ny,Nz);

F = @(x) fftshift(fft2(ifftshift(x)));
Ft = @(x) fftshift(ifft2(ifftshift(x)));

cx=floor(nx/2)+1;cy=floor(ny/2)+1;
[Nx_temp, Ny_temp]=size(Ampl_source);cx_temp=floor(Nx_temp/2)+1;cy_temp=floor(Ny_temp/2)+1;

if nx>Nx_temp || ny>Ny_temp
    sprinf('Error in scaledSourceFFT.nx,ny should be smaller than size of Ampl_source. You may write code to zeropadding Ampl_source but that is not suggested..');
    return;
end

Nz=length(z);

if isa(Ampl_source,'gpuArray')
    Source_fft_Nstack=gpuArray.zeros(nx,ny,Nz);
else
    Source_fft_Nstack=zeros(nx,ny,Nz);
end


 for nz=1:Nz
     
    ScaleFactor=z(nz)*ps_source/(ps);
    
    if abs(ScaleFactor)<=1
    Source_fft_temp=DownSample_zeropadding(Ampl_source,ScaleFactor);
    elseif abs(ScaleFactor)>1
    Source_fft_temp=UpSample_zeropadding(Ampl_source,ScaleFactor);
    end
    
    Source_temp=Ft(Source_fft_temp);
    Source_fft_Nstack(:,:,nz)=fft2(ifftshift((Source_temp((cx_temp+1-cx):(cx_temp-cx+nx),(cy_temp+1-cy):(cy_temp-cy+ny)))));%Ampl_source larger than intensity size
    %note that Source_fft_Nstack(:,:,nz) needs to be fftshift to works for
    %the case of fftshift(fft2(ifftshift(x))) operator
    
    
    %show scaled source
%     Source_nz=Ft(Source_fft_Nstack(:,:,nz)); %scaled source in spatial domain
%     
%     subplot(2,2,1);
%     imagesc(abs(Source_nz));
%     axis image;axis off;colormap gray;colorbar;
%     title(sprintf('Source at %d',nz));
% 
% 
%     subplot(2,2,2);
%     imagesc(abs(Source_fft_Nstack(:,:,nz)));
%     axis image;axis off;colormap gray;colorbar;
%     title(sprintf('Source Fourier transform at %d',nz));
%     
%     subplot(2,2,3);
%     imagesc(angle(Source_nz));
%     axis image;axis off;colormap gray;colorbar;
%     title(sprintf('angle of Source_nz at %d',nz));
    
 %  pause(0.2);
 end