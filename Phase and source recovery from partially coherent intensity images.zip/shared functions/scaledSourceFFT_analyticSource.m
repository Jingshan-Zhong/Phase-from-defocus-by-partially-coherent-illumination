function Source_fft_Nstack=scaledSourceFFT_analyticSource(fftsource, z, ps)

global Ividmeas;

[Nx,Ny,Nz]=size(Ividmeas);

cx=floor(Nx/2)+1;cy=floor(Ny/2)+1;
[us, vs]=ndgrid([1:Nx]-cx,[1:Ny]-cy);
us=us/Nx/ps; vs=vs/Ny/ps;
us=ifftshift(us); vs=ifftshift(vs);

Source_fft_Nstack=zeros(Nx,Ny,Nz); %store inverse Fourier transform in each step

for nz=1:Nz
 Source_fft_Nstack(:,:,nz)=fftsource(z(nz)*us,z(nz)*vs);
end

if isa(z,'gpuArray')
    Source_fft_Nstack=gpuArray(Source_fft_Nstack);
end