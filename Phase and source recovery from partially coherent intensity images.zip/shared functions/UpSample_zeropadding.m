function Img_scaled_fft=UpSample_zeropadding(Img,ScaleFactor)
%1) scale Img by a factor of ScaleFactor (larger than 1)
%2) Note: this func returns FFT of the scaled image
%3) Only confirm that this function works for Img is real

F = @(x) fftshift(fft2(ifftshift(x))); %different from the definition of F in the code before 10/21/2014
Ft = @(x) fftshift(ifft2(ifftshift(x))); %different from the definition of F in the code before 10/21/2014

[Nx,Ny]=size(Img);
cx=floor(Nx/2)+1;cy=floor(Ny/2)+1;

if abs(ScaleFactor)<1
    sprintf('Error in Img_scaled_fft. The ScaleFactor is larger than 1 but this is a upsample function.');
    return;
end

Nx_zp=floor(Nx*abs(ScaleFactor));Ny_zp=floor(Ny*abs(ScaleFactor));%zp for zeropadding
cx_zp=floor(Nx_zp/2)+1;cy_zp=floor(floor(Ny_zp/2))+1;

Imgfft=F(Img);


if isa(Img,'gpuArray')
    Imgfft_zp=gpuArray.zeros(Nx_zp,Ny_zp);
else
    Imgfft_zp=zeros(Nx_zp,Ny_zp);
end

Imgfft_zp((cx_zp-cx+1):(cx_zp+Nx-cx),(cy_zp-cy+1):(cy_zp+Ny-cy))...
    =Imgfft;%zero_padding Img by placing it in the image center,surrounded by zeros

if ScaleFactor>0
    
    Img_zp=Ft(Imgfft_zp);
    Img_scaled=Img_zp((cx_zp-cx+1):(cx_zp+Nx-cx),(cy_zp-cy+1):(cy_zp+Ny-cy)); %take the central part
    Img_scaled_fft=F(Img_scaled); %take the central part
    
elseif ScaleFactor<0
    Imgfft_zp((2*cx_zp-Nx_zp):Nx_zp,(2*cy_zp-Ny_zp):Ny_zp)=Imgfft_zp(Nx_zp:-1:(2*cx_zp-Nx_zp),Ny_zp:-1:(2*cy_zp-Ny_zp));
    %Step 1) flip the image/image_fft if the scalefactor is smaller than zero[1 2 3 4] become [1 4 3 2]  
    Img_zp=Ft(Imgfft_zp);
    Img_scaled=Img_zp((cx_zp-cx+1):(cx_zp+Nx-cx),(cy_zp-cy+1):(cy_zp+Ny-cy)); %take the central part
    Img_scaled_fft=F(Img_scaled); %take the central part
end