Ver 1: work for CPU
ver 2: compuatible both for CPU and GPU