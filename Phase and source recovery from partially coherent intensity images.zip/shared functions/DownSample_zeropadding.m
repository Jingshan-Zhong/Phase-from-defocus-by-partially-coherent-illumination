
function Img_scaled_fft=DownSample_zeropadding(Img,ScaleFactor)
%1) scale Img by a factor of ScaleFactor (smaller than 1)
%2) use zeropadding method: refer to 'ResizeSource_zeropadding' in folder...
%...named \Source deconvolution\Resize Techniques testing
%3) Note: this func returns FFT of the scaled image
%4) ZeroPadding_x=Nx/ScaleFactor;ZeroPadding_y=Ny/ScaleFactor;
    %K2=exp(-1i*2*pi*((us(:)/ZeroPadding_x)*xs(:)'+(vs(:)/ZeroPadding_y)*ys(:)'));%for scale
    %returns reshape(K2*Img(:),Nx,Ny)
%5) works for complex Img



F = @(x) fftshift(fft2(ifftshift(x))); %different from the definition of F in the code before 10/21/2014
Ft = @(x) fftshift(ifft2(ifftshift(x))); %different from the definition of F in the code before 10/21/2014

[Nx,Ny]=size(Img);
cx=floor(Nx/2)+1;cy=floor(Ny/2)+1;


if abs(ScaleFactor)>1
    sprintf('Error in Img_scaled_fft. The ScaleFactor is larger than 1 but this is a downsample function.');
    return;
end

if ScaleFactor==0 %when ScaleFactor==0. The scaled img has impulse at center
    if isa(Img,'gpuArray')
        Img_zp=gpuArray.zeros(Nx,Ny);
    else
        Img_zp=zeros(Nx,Ny);
    end
    
    
    Img_zp(cx,cy)=sum(sum(Img));
    Img_scaled_fft=F(Img_zp);
    return;

end

if floor(Nx/abs(ScaleFactor))>5*10^3|| floor(Ny/abs(ScaleFactor))>5*10^3 %if scale factor is too small, scale twice
    S1=sqrt(abs(ScaleFactor));S2=ScaleFactor/abs(ScaleFactor)*sqrt(abs(ScaleFactor));
    Img_scaled_fft1=DownSample_zeropadding(Img,S1);
    Img_scaled_fft=DownSample_zeropadding(Ft(Img_scaled_fft1),S2);
    return;
end


Nx_zp=floor(Nx/abs(ScaleFactor));Ny_zp=floor(Ny/abs(ScaleFactor));%zp for zeropadding
cx_zp=floor(Nx_zp/2)+1;cy_zp=floor(floor(Ny_zp/2))+1;

if isa(Img,'gpuArray')
    Img_zp=gpuArray.zeros(Nx_zp,Ny_zp);
else
    Img_zp=zeros(Nx_zp,Ny_zp);
end

if ScaleFactor>0
    
    Img_zp((cx_zp-cx+1):(cx_zp+Nx-cx),(cy_zp-cy+1):(cy_zp+Ny-cy))...
        =Img;%zero_padding Img by placing it in the image center,surrounded by zero    
    Img_zp_fft=F(Img_zp);   
    Img_scaled_fft=Img_zp_fft((cx_zp-cx+1):(cx_zp+Nx-cx),(cy_zp-cy+1):(cy_zp+Ny-cy)); %take the central part
    
elseif ScaleFactor<0
    %y=K_2 b=(K_1 (b^*))^*;where K_2 is the FFT matrix of scale factor
    %smaller than zero, and K_1 is the FFT matrix of scale factor
    %larger than zero. K_2=K_1^*;
   
    Img_zp((cx_zp-cx+1):(cx_zp+Nx-cx),(cy_zp-cy+1):(cy_zp+Ny-cy))...
        =conj(Img);%zero_padding Img by placing it in the image center,surrounded by zero    
    Img_zp_fft=F(Img_zp);   
    Img_scaled_fft=Img_zp_fft((cx_zp-cx+1):(cx_zp+Nx-cx),(cy_zp-cy+1):(cy_zp+Ny-cy)); %take the central part
   
    Img_scaled_fft= conj(Img_scaled_fft); %Step 2) Take conjugate
end