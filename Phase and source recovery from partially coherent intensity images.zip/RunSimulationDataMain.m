 % This code is for recovering phase for coherent defocus stack with nonlinear optimization method.
% The derivation of the methods in the code is shown in our paper (in review Jan. 2016): 'Nonlinear Optimization Algorithm for Partially Coherent Phase Retrieval and Source Recovery'
% Contact: Jingshan Zhong 
% Email: jingshanzhong@gmail.com
% Website: http://www.laurawaller.com/opensource/

clear all; close all;
 
addpath('Source deconvolution');
addpath('shared functions');

global Ividmeas HStack Source_fft_Nstack;
F = @(x) fft2(x);
Ft = @(x) ifft2(x);

 %% Loading defocus stack with partially coherent illumination

%load ParCoherent_CircleNA005; %simulations
load ExperimetalData_MCFcells_PartiallyCoherentDefocusStack; %experimental data measured on microscope

IsGPUprogram=1; %choose whether run on gpu. 1 = yes; 0 = no.
[Nx, Ny, Nz]=size(Ividmeas); 
cx=floor(Nx/2)+1;cy=floor(Ny/2)+1;


%% First iteration: Initializing with source with coherent source. Next use the coherent source to solve the complex field

%%%%%%%%%%%%%load the parameters into GPU if IsGPUprogram=1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if IsGPUprogram==1
Ividmeas = gpuArray(Ividmeas);  Nx=gpuArray(Nx);Ny=gpuArray(Ny);z=gpuArray(z); nfocus=gpuArray(nfocus);lambda=gpuArray(lambda);ps=gpuArray(ps);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[HStack]=GenerateFresnelPropagationStack(Nx,Ny,z, nfocus, lambda, ps);

bhat0=fft2(Ividmeas(:,:,nfocus).^(1/2));%initialization
MaxIter=5; %initialization
StopCond=10^-6*mean(mean(mean(Ividmeas)));
%parameters for line search
c=1/2;gamma=1/2;eps1=10^-6;

%%%%%%%%%%%%%%%%%%%%%%load the parameters into GPU if IsGPUprogram=1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if IsGPUprogram==1  
bhat0=gpuArray(bhat0);MaxIter=gpuArray(MaxIter);StopCond=gpuArray(StopCond);c=gpuArray(c); gamma=gpuArray(gamma);eps1=gpuArray(eps1); 
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

EstSource=zeros(gather(Nx),gather(Ny)); EstSource(floor(Nx/2)+1,floor(Ny/2)+1)=1; %coherent source

[zmax, zmax_n]=max(abs(z));%zmax is dummy here.
zmax=z(zmax_n);%find the most defocused position
ps_source=ps/zmax; %ps_source has no unit

if IsGPUprogram==1
    ps_source=gpuArray(ps_source); EstSource=gpuArray(EstSource);
end

Source_fft_Nstack=scaledSourceFFT(Nx,Ny,ps,ps_source,EstSource,z);

if IsGPUprogram==1
    Source_fft_Nstack=gpuArray(Source_fft_Nstack);
end

%initialize with small z distance and coherent phase
Ividmeas1=gather(Ividmeas); Source_fft_Nstack1=gather(Source_fft_Nstack); HStack1=gather(HStack); 

Nz_small=6;% since coherent source is more accurate for small defocus distance, we only use intensity images of small defocus distance to solve the complex field at first iteration.

Ividmeas=Ividmeas(:,:,nfocus-Nz_small:nfocus+Nz_small);
Source_fft_Nstack=Source_fft_Nstack(:,:,nfocus-Nz_small:nfocus+Nz_small);
HStack=HStack(:,:,nfocus-Nz_small:nfocus+Nz_small);

bhat0=IterativeOptimization(@CalErr,@CalGradient,bhat0,MaxIter,StopCond,c,gamma,eps1);


if IsGPUprogram==1
    Ividmeas=gpuArray(Ividmeas1); Source_fft_Nstack=gpuArray(Source_fft_Nstack1); HStack=gpuArray(HStack1);
    clear Ividemas1 Source_fft_Nstack1 HStack1;
else
    Ividmeas=Ividmeas1; Source_fft_Nstack=Source_fft_Nstack1; HStack=HStack1;
    clear Ividemas1 Source_fft_Nstack1 HStack1;
end


%% looping through both source and phase recovery steps

NIter=30; % number to loops between source and phase recovery steps
tic

%parameter of source estiamtion
EstSource=zeros(gather(Nx),gather(Ny));

maxiter_source=50; % maximum iteration when usin CG to solve the source
bw=200; % bandwith of the recovered frequency of the source.
MaxIter2=2; %iteration for complex field

if IsGPUprogram==1
EstSource=gpuArray(EstSource); maxiter_source=gpuArray(maxiter_source); bw=gpuArray(bw); MaxIter2=gpuArray(MaxIter2);
end

figure;
for k=1:NIter

%source estimation   
EstCohIntStack=abs(ifft2(bsxfun(@times,HStack,bhat0))).^2;%Fresnel propagation bhat0, inverse Fourier transform and take intensity
[EstSource]=DeconvSource_leastMeanSquare_FastApproximatebyCG(Ividmeas,EstCohIntStack,z,ps/ps_source,bw,EstSource,maxiter_source);
EstSource=real(EstSource); 
%EstSource=EstSource/(sum(sum(EstSource)));

%phase recovery
Source_fft_Nstack=scaledSourceFFT(Nx,Ny,ps,ps_source,EstSource,z); 
bhat0=IterativeOptimization(@CalErr,@CalGradient,bhat0,MaxIter2,StopCond,c,gamma,eps1);

%display recovered source and phase
subplot(2,2,1);imagesc(EstSource);axis image;axis off; colormap gray; colorbar;title('Estimated illumination pattern');
subplot(2,2,3);imagesc(angle(gather(ifft2(bhat0)))); axis image;axis off; colormap gray; colorbar;title('Estimated phase');
subplot(2,2,4);imagesc(abs(gather(fftshift(bhat0))).^(0.2)); axis image;axis off; colormap gray; colorbar;title('FFT of bhat0');

pause(0.1);
display(k);
toc

end

ahat0=ifft2(bhat0);
ahat0=gather(ahat0);

%% show result

figure;
subplot(1,2,1)
imagesc(EstSource);axis image;axis off; colormap gray; colorbar;title('Estimated illumination pattern');
subplot(1,2,2)
imagesc(abs(fftshift(fft2(EstSource))).^(0.2));axis image;axis off; colormap gray; colorbar;title('FFT of estimated illumination pattern');

figure;
imagesc(abs(ahat0.^2));
axis image;axis off;colormap gray
title('Estimated intensity');colorbar

figure;
imagesc(angle(ahat0));
%imagesc(angle(ahat0));
axis image;axis off;colormap gray
title('Estimated phase');colorbar
 
%% see more recovered results
% figure;
% subplot(2,2,1);
% imagesc(fftshift(sum(abs(Source_fft_Nstack).*abs(imag(HStack)),3)));
% axis image;axis off; colormap gray; colorbar;title('Sum of F(S(z)) times imag(H)');
% 
% subplot(2,2,2);
% imagesc(1./fftshift(sum(abs(Source_fft_Nstack).*abs(imag(HStack)),3))); %,[1 10]
% axis image;axis off; colormap gray; colorbar;title('Invert Sum of F(S(z)) times imag(H)');
% 
% 
% subplot(2,2,3);
% imagesc(fftshift(sum(abs(imag(HStack)),3)));
% axis image;axis off; colormap gray; colorbar;title('Sum of imag(H)');
% 
% subplot(2,2,4);
% imagesc(1./fftshift(sum(abs(imag(HStack)),3)),[1 10]);
% axis image;axis off; colormap gray; colorbar;title('Invert Sum of imag(H)');

%save('-v7.3',savefn,'ahat0','ahatOriginal','EstSourceOri','EstSource','ps_source');

% figure;
% for nz=1:Nz
%     temp1=fftshift(gather(Source_fft_Nstack(:,:,nz)));
%     
%     subplot(1,2,1);
% imagesc(abs(temp1).^(0.2));
% axis image;axis off; colormap gray; colorbar;title(sprintf('Amplitude of fft of scaled source at %d',nz));
% 
%     subplot(1,2,2);
% imagesc(angle(temp1));
% axis image;axis off; colormap gray; colorbar;title(sprintf('phase of fft of scaled source at %d',nz));
% 
% pause(0.2);
%     
% end

% figure;
% for nz=1:Nz
%     imagesc(Ividmeas(:,:,nz));axis image;axis off;colormap gray
%     title(sprintf('Measured Intensity at %d',nz));colorbar
%     pause(0.2);
% end


