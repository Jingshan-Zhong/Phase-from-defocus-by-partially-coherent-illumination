function ImgFiltered=Circlelowpassfilter_ZJS(Img,lowpassbandx,lowpassbandy)

[Nx,Ny]=size(Img);
F = @(x) fftshift(fft2(ifftshift(x))); %different from the definition of F in the code before 10/21/2014
Ft = @(x) fftshift(ifft2(ifftshift(x))); %different from the definition of F in the code before 10/21/2014

%lowpassband=20;

Mask=zeros(Nx,Ny);
cx=floor(Nx/2)+1;cy=floor(Ny/2)+1;

[xx,yy] = ndgrid([1:Nx]-cx,[1:Ny]-cy);
r=((xx/lowpassbandx).^2+(yy/lowpassbandy).^2).^(1/2);
Mask(find(r<1))=1;

ImgFiltered_fft=F(Img).*Mask;

ImgFiltered=Ft(ImgFiltered_fft);

figure;
imagesc(Mask); axis image;axis off;colormap gray; title(sprintf('low pass filter of bandpassx= %d and bandpassy= %d',lowpassbandx,lowpassbandy));



