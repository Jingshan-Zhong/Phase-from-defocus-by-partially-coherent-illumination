function bhat0=IterativeOptimization(f,df,bhat0,Ite,StopCond,c,gamma,eps1)
%the old name of this function is CoherentPhaseSteepGradient
%Gradient method for phase retrieval


if isa(Ite,'gpuArray')
Err=gpuArray.zeros(Ite);
fcallstack=gpuArray.zeros(Ite);
CGIte=gpuArray.zeros(Ite);

else  
Err=zeros(Ite);
fcallstack=zeros(Ite);
CGIte=zeros(Ite);
end

fk=feval(f,bhat0);

%tic
%figure;
for k=1:Ite
      
  %  ahat0=ifft2(bhat0);
    
%     subplot(2,2,1);
%     imagesc(angle(gather(ahat0)));
%     axis image;axis off; colormap gray; colorbar;title('Estimated phase');
%     
%     subplot(2,2,2);
%     imagesc(abs(gather(fftshift(fft2(angle(ahat0))))).^(0.2));
%     axis image;axis off; colormap gray; colorbar;title('FFT of Estimated phase');
%     
%     subplot(2,2,3);
%     imagesc(abs(gather(fftshift(bhat0))).^(0.2));
%     axis image;axis off; colormap gray; colorbar;title('FFT of ahat0');
    
    %pause(0.1)
    
    [dfda]=feval(df,bhat0);
    dfdasum=sqrt(sum(sum(abs(dfda).^2)));
   if dfdasum <= StopCond
        disp('Meeting stopping condtions in step gradient method')
        break
    end
    
  %  searchdirection=-dfda;%steep gradient
    
    b=-0.5*dfda; CGinit=b; maxiter=10;
    [searchdirection, niter, flag] = solveCG(@JHJx,bhat0, b, CGinit, dfdasum*10^-3, maxiter);
    CGIte(k)=niter;
    
    
    %line search
    DDfnc=real(sum(sum(conj(searchdirection).*dfda)));
    %display(DDfnc);
    
    if DDfnc>0
        searchdirection=-dfda; %steep gradient
        DDfnc=real(sum(sum(conj(searchdirection).*dfda)));
    end
    
    [bhat0,fk,fcall] = backtrack(bhat0,searchdirection,fk,f,DDfnc,c,gamma,eps1);
    fcallstack(k)=fcall;
    Err(k)=fk;
    
   % toc
    display(sprintf('Iteration= %d, Err=%f, fcallnumber=%d',k,fk,fcall));
  
    
    
end


% figure;
% plot([1:Ite],Err);
% 
% figure;
% plot([1:Ite],fcallstack);
% 
% figure;
% plot([1:Ite],CGIte);