clear all;close all;
addpath('C:\Users\zjs\Dropbox\Partial Coherence Project\partial_coherence_simulation');
addpath('../partial_coherence_simulation//Partial Coherence Simulation GPU//Partial Coherence Simulation');
addpath('C:\Users\Jingshan\Dropbox\Partial Coherence Project\partial_coherence_simulation\Partial Coherence Simulation GPU\Partial Coherence Simulation');
addpath('C:\Users\Jingshan\Dropbox\Partial Coherence Project\partial_coherence_simulation');
addpath('..\\..\\shared functions')

F = @(x) fftshift(fft2(ifftshift(x))); %different from the definition of F in the code before 10/21/2014
Ft = @(x) fftshift(ifft2(ifftshift(x))); %different from the definition of F in the code before 10/21/2014

%% loading simulated data
%load ParCoherent_CircleNA005;
%load ParCoherent_ringNA003NA002;
%load ParCoherent_ringNA007NA003;
%load PartialCoherent__Stack3bySumAllComponents_SourceSizeLargerThanImageSize;
%load PartialCoherent__Stack5bySumAllComponents;
%load ParCoherent_Lena1;
load ParCoherent_Lena2;

%adding noise
%Ividmeas=Ividmeas_noNA;
NoiseLevel=0.00;
ImageNumber=16;Imgdn=1;nstart=0;
%ImgIndex=[-32 -16 -8 -4 -2 2 4 8 16 32]*Imgdn+nfocus; 

ImgIndex=[-((ImageNumber:-1:1)*Imgdn+nstart) 0 ((1:1:ImageNumber)*Imgdn+nstart)]+nfocus; %Images index

Ividmeas1=Ividmeas(:,:,ImgIndex);z=z(ImgIndex)'-z(nfocus); nfocus=ImageNumber;
Ividmeas=Ividmeas1+randn(size(Ividmeas1))*NoiseLevel;%adding Gausssian noise

TrueIntensity=Ividmeas1; %for experimental data;
IvidmeasCentral=IvidmeasCentral(:,:,ImgIndex);
[Nx, Ny, Nz]=size(Ividmeas);


IsGPUprogram=0; %choose whether run on gpu


%% Source Reconstruction

EstSource=zeros(Nx,Ny);
EstSource(floor(Nx/2)+1,floor(Ny/2)+1)=0;

[zmax, zmax_n]=max(abs(z));%zmax is dummy here.
zmax=abs(z(zmax_n));%find the most defocused position
ps_source=ps/zmax;


x0=zeros(Nx,Ny); 
%x0=EstSource; %initialize in CG source estimation
maxiter=500;
bw=100; % bandwith of the recovered frequency of the source.

if IsGPUprogram==1
    Ividmeas=gpuArray(Ividmeas); IvidmeasCentral=gpuArray(IvidmeasCentral);z=gpuArray(z);
    bw=gpuArray(bw);x0=gpuArray(x0);
end

[EstSource]=DeconvSource_leastMeanSquare_FastApproximatebyCG(Ividmeas,IvidmeasCentral,z,ps/ps_source,bw,x0,maxiter);


figure(2);
imagesc(real(EstSource));axis image;axis off; colormap gray; colorbar;title('Estimated illumination pattern');

%% show Estimated Source; show the source at the most defocused z

%{

Source=zeros(Nx,Ny);
%[NA_radius, Source]=circlesource(Source,NA,zmax,ps);%for circle source
[NA_radius, Source1]=circlesource(Source,NA2,zmax,ps);
[NA_radius, Source2]=circlesource(Source,NA1,zmax,ps);
Source=max(Source1(:))*Source2-max(Source2(:))*Source1;
Source=Source/sum(sum(Source));


SourceErr=Source-real(EstSource);
%save('Lena00005noiseResult','Source','EstSource');

colorbarMin=min(min(real(Source)));
colorbarMax=max(max(real(Source)));
figure;
subplot(2,2,1);
imagesc(Source,[colorbarMin colorbarMax]);axis image;axis off; colormap gray; colorbar; title('Original illumination pattern');
subplot(2,2,2);
imagesc(real(EstSource),[colorbarMin colorbarMax]);axis image;axis off; colormap gray; colorbar;title('Estimated illumination pattern');
subplot(2,2,3);
imagesc(SourceErr);axis image;axis off; colormap gray; colorbar;title('Error');

figure;
imagesc(abs(F(EstSource)));axis image;axis off; colormap gray; colorbar;


%}

%% for paper

Source=zeros(Nx,Ny);
%circle
%[NA_radius, Source]=circlesource(Source,NA,zmax,ps);%for circle source
%ring
% [NA_radius, Source1]=circlesource(Source,NA2,zmax,ps);
% [NA_radius, Source2]=circlesource(Source,NA1,zmax,ps);
% Source=max(Source1(:))*Source2-max(Source2(:))*Source1;
% Source=Source/sum(sum(Source));
%arbitary
Source=Ampl_source;

SourceErr=Source-real(EstSource);
SumErr=sqrt(sum(sum(SourceErr.^2)))
%save('Lena00005noiseResult','Source','EstSource');

colorbarMin=min(min(real(EstSource)));
colorbarMax=max(max(real(EstSource)));
figure;
imagesc(Source,[colorbarMin colorbarMax]);axis image;axis off; colormap gray; colorbar; 

figure;
imagesc(real(EstSource),[colorbarMin colorbarMax]);axis image;axis off; colormap gray; colorbar;

figure;
imagesc(SourceErr);axis image;axis off; colormap gray; colorbar;

figure;
imagesc(IvidmeasCentral(:,:,1),[0.85 1.1]); axis image; axis off;colormap gray;colorbar;

figure;
imagesc(Ividmeas(:,:,1),[0.976 1.0223]); axis image; axis off;colormap gray;colorbar;
%%
% figure(2);
% for nz = 1:length(z)
%     
%     subplot(1,2,1);
%     imagesc(IvidmeasCentral(:,:,nz));
%     axis image; axis off;colormap gray
%     title(sprintf('Central beam Intensity at z step %d',nz));colorbar
%     
%     subplot(1,2,2)
%     imagesc(Ividmeas(:,:,nz));
%     axis image; axis off; colormap gray
%     title(sprintf('Partial coherence intensity at z step %d',nz));colorbar
%     
%     %saveas(gcf,[savefile sprintf('%d.tif',nz)]);
%     pause(0.1);
% end




