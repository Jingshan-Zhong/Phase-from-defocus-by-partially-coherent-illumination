function [NA_radius,Source]=circlesource(Source,NA,zmax,ps)

[Nx,Ny]=size(Source);
ps_NA= ps/(zmax); 
cx=floor(Nx/2)+1;cy=floor(Ny/2)+1;

[xx,yy] = meshgrid([1:Nx]-cx,[1:Ny]-cy);% coordinates of points on led 
xx=xx*ps_NA;
yy=yy*ps_NA;

if isa(Source,'gpuArray')
    Source=gpuArray.zeros(Nx,Ny);
else
    Source=zeros(Nx,Ny);
end

Source(find(sqrt((xx).^2+(yy).^2)<=NA))=1; %constant led amplitude inside the source
NA_radius=floor(NA/ps_NA);
Source=Source/sum(sum(Source));