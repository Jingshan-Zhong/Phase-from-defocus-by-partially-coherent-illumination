function [y]=Qx(SQ,LP,x)
%y=(Q^HQx+c.c.)
% ab=fftshift(ifft2(ifftshift(fftshift(fft2(ifftshift(a))).*fftshift(fft2(ifftshift(b)))))); %no need to ifftshift
% ab2=ifft2(fft2(ifftshift(a)).*fft2(b));
% ab is equal to ab2; SQ and LP has been ifftshifted out side of Qx
% 
% F = @(x) fftshift(fft2(ifftshift(x))); %different from the definition of F in the code before 10/21/2014
% Ft = @(x) fftshift(ifft2(ifftshift(x))); %different from the definition of F in the code before 10/21/2014



[Nx, Ny]=size(x); 


x=ifft2(fft2(x).*LP);


[Nx_zp, Ny_zp]=size(SQ);

  if isa(x,'gpuArray')
        xb_zp=gpuArray.zeros(Nx_zp, Ny_zp);
    else
        xb_zp=zeros(Nx_zp, Ny_zp);
  end
    
  
xb_zp(end-Nx+1:1:end,end-Ny+1:1:end)=x;


b2_zp=ifft2(fft2(xb_zp).*SQ);


y=b2_zp(1:Nx,1:Ny);

y=real(ifft2(fft2(y).*conj(LP)));