function [EstSource]=DeconvSource_leastMeanSquare_FastApproximatebyCG(Ividmeas,IvidmeasCentral,z,zmax,bw,x0,maxiter)


F = @(x) fftshift(fft2(ifftshift(x))); 
Ft = @(x) fftshift(ifft2(ifftshift(x))); 

[Nx,Ny,Nz]=size(Ividmeas);

cx=floor(Nx/2)+1;cy=floor(Ny/2)+1;

if isa(Ividmeas,'gpuArray')
b=gpuArray.zeros(Nx,Ny);
Scaled_fft_sum=gpuArray.zeros((2*Nx-1),(2*Ny-1));
else
b=zeros(Nx,Ny);
Scaled_fft_sum=zeros((2*Nx-1),(2*Ny-1));
end


%Q2=zeros(N,N);
%tic
for nz=1:Nz
     ScaleFactor=z(nz)/zmax;
     
     InCh_fft=F(IvidmeasCentral(:,:,nz));  

     Temp4=CalKDK(abs(InCh_fft.^2),ScaleFactor);    

     Scaled_fft_sum=Scaled_fft_sum+Temp4;
 
     In_fft=F(Ividmeas(:,:,nz));
     
     Temp2=conj(DownSample_zeropadding(conj((conj(InCh_fft).*In_fft)),ScaleFactor));
     
     b=b+Temp2;  
     %display(nz);
     %toc   
end

%x0=zeros(Nx,Ny); maxiter=500;

clear Ividmeas IvidmeasCentral InCh_fft Temp4 In_fft Temp2;

%% solve Qx=b with conjugate gradient method


[us,vs]=ndgrid([1:Nx]-cx,[1:Ny]-cy); 
LP=zeros(Nx,Ny);
LP((us.^2+vs.^2)<=bw^2)=1;% low pass filter. Frequency out of the bandwidth is not estimated.

%figure; imagesc(LP); colorbar; title('Low pass filter');

if isa(Scaled_fft_sum,'gpuArray')
LP=gpuArray(LP);
end

b=Ft(F(b).*LP);
b0=real(b);% b is real. The imag part is from numerical error.

[Nx_zp, Ny_zp]=size(Scaled_fft_sum);
repSQ=repmat(Scaled_fft_sum,2,2);
SQ=repSQ(Nx_zp+1:-1:2,Ny_zp+1:-1:2);
SQ=fftshift(SQ); %for computing Qx

%get rid of fftshift things
SQ=fft2(ifftshift(SQ));
LP=ifftshift(LP);


%tic
[EstSource, niter, flag] = solveSourceWithCG(@Qx,SQ, LP, b0, x0, 10^-3, maxiter); %10^-3 is stopping creteria in CG
%toc


%save('Angular_PCsourceEstimation','Q','b','Scaled_fft_sum','EstSource');

