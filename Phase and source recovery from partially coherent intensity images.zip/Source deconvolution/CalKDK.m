function KDK=CalKDK(Img,ScaleFactor)
%only works when Img is real
%use FFT to calculate following:
% cx=floor(Nx/2)+1;cy=floor(Ny/2)+1;
% [xs,ys]=ndgrid([1:Nx]-cx,[1:Ny]-cy); 
% [us2,vs2]=ndgrid([-1*(Nx-1):(Nx-1)],[-(Ny-1):(Ny-1)]); 
% ZeroPadding_x=Nx/ScaleFactor;ZeroPadding_y=Ny/ScaleFactor;
% K22=exp(-1i*2*pi*((us2(:)/ZeroPadding_x)*xs(:)'+(vs2(:)/ZeroPadding_y)*ys(:)'));%for scale
% KDK=K22'*diag(Img(:))*K22; %KDK has size of 2Nx-1 by 2Ny-1;

F = @(x) fftshift(fft2(ifftshift(x))); %different from the definition of F in the code before 10/21/2014
Ft = @(x) fftshift(ifft2(ifftshift(x))); %different from the definition of F in the code before 10/21/2014

[Nx,Ny]=size(Img);
cx=floor(Nx/2)+1;cy=floor(Ny/2)+1;

Nx2=2*Nx-1;Ny2=2*Ny-1;
cx2=Nx;cy2=Ny;

if ScaleFactor==0 %when ScaleFactor==0. The scaled img has impulse at center
    %more test
    
    if isa(Img,'gpuArray')
        Img_zp=gpuArray.zeros(Nx2,Ny2);
    else
        Img_zp=zeros(Nx2,Ny2);
    end
    
    Img_zp(cx2,cy2)=sum(sum(Img));
    KDK=F(Img_zp);
    return;
end

if floor(Nx/abs(ScaleFactor))>5*10^3|| floor(Ny/abs(ScaleFactor))>5*10^3 %if scale factor is too small, scale twice
    
    S2=ScaleFactor/abs(ScaleFactor)*1/3; S1=ScaleFactor/S2;
    if S1<1
    Img_scaled_fft1=DownSample_zeropadding(Img,S1);
    Img=Ft(Img_scaled_fft1);
    [Nx,Ny]=size(Img);
    cx=floor(Nx/2)+1;cy=floor(Ny/2)+1;
     ScaleFactor=S2;
    end

end

Nx_zp=floor(Nx/abs(ScaleFactor));Ny_zp=floor(Ny/abs(ScaleFactor));%zp for zeropadding
cx_zp=floor(Nx_zp/2)+1;cy_zp=floor(floor(Ny_zp/2))+1;



if isa(Img,'gpuArray')
    Img_zp=gpuArray.zeros(Nx_zp,Ny_zp);
else
    Img_zp=zeros(Nx_zp,Ny_zp);
end

Img_zp((cx_zp-cx+1):(cx_zp+Nx-cx),(cy_zp-cy+1):(cy_zp+Ny-cy))...
    =Img;%zero_padding Img by placing it in the image center,surrounded by zeros

Img_zp_fft=F(Img_zp);
if ScaleFactor<0
    Img_zp_fft= conj(Img_zp_fft); %flip the image/image_fft if the scalefactor is smaller than zero
end

if Nx_zp<Nx2||Ny_zp<Ny2
    
    if isa(Img,'gpuArray')
        Temp1=gpuArray.zeros(3*Nx_zp,3*Ny_zp);
    else
        Temp1=zeros(3*Nx_zp,3*Ny_zp);
    end
    
    for kx=1:3
        for ky=1:3
            x0=(kx-1)*Nx_zp+1; y0=(ky-1)*Ny_zp+1;
            Temp1(x0:x0+Nx_zp-1,y0:y0+Ny_zp-1)=Img_zp_fft;
        end
    end
    KDK=Temp1((Nx_zp+cx_zp-cx2+1):(Nx_zp+cx_zp+Nx2-cx2),(Ny_zp+cy_zp-cy2+1):(Ny_zp+cy_zp+Ny2-cy2));
    %(Nx_zp+cx_zp,Ny_zp+cy_zp) is the center of Temp1
    
else
    KDK=Img_zp_fft((cx_zp-cx2+1):(cx_zp+Nx2-cx2),(cy_zp-cy2+1):(cy_zp+Ny2-cy2));
end
%Img_scaled_fft=Img_zp_fft((cx_zp-cx+1):(cx_zp+Nx-cx),(cy_zp-cy+1):(cy_zp+Ny-cy)); %take the central part
