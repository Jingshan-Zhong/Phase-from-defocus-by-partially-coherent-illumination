 clear all; close all;
 

 
addpath('Source deconvolution');
addpath('shared functions');


global Ividmeas HStack Source_fft_Nstack;
F = @(x) fft2(x);
Ft = @(x) ifft2(x);

 %% %%% Loading data

%load ParCoherent_ringNA003NA002;
%load ParCoherent_Lena1;
%load ParCoherent_CircleNA005;
%load 2013123OneImageMedium; 

 filename='MFC10PC0228Medium'; 
 savefn=[filename ' SourceEstimationResult'];
 load(filename); 



% choosing a stack of defocused images as inputs
ImageNumber=14;Imgdn=1;nstart=0;
ImgIndex=[-((ImageNumber:-1:1)*Imgdn+nstart) 0 ((1:1:ImageNumber)*Imgdn+nstart)]+nfocus; %Images index

TrueIntensity=Ividmeas(:,:,ImgIndex);z=z(ImgIndex)'-z(nfocus);  
nfocus=ImageNumber+1; %Ividmeas(229:2114,308:2476,ImgIndex);523:1775,549:2018
%ps=2*ps;


NoiseLevel=0.00;
Ividmeas=TrueIntensity+randn(size(TrueIntensity))*NoiseLevel;%adding Gausssian noise 

%Ividmeas=Ividmeas(1:end-1,1:end-1,:);
Ividmeas=Ividmeas(122:2:1053,70:2:873,:); ps=2*ps;

IsGPUprogram=1; %choose whether run on gpu. 1 = yes; 0 = no.
[Nx, Ny, Nz]=size(Ividmeas); 
cx=floor(Nx/2)+1;cy=floor(Ny/2)+1;



%% Gradient method to solve phase

%%%%%%%%%%%%%load the parameters into GPU if IsGPUprogram=1 %%%%%%%%%%%%%%%%%%%%%%%%%%
if IsGPUprogram==1
Ividmeas = gpuArray(Ividmeas);  
Nx=gpuArray(Nx);Ny=gpuArray(Ny);z=gpuArray(z);
nfocus=gpuArray(nfocus);lambda=gpuArray(lambda);ps=gpuArray(ps);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[HStack]=GenerateFresnelPropagationStack(Nx,Ny,z, nfocus, lambda, ps);


bhat0=fft2(Ividmeas(:,:,nfocus).^(1/2));%initialization
%bhat0=fft2(abs(randn(gather(Nx),gather(Ny)))*mean(mean(mean(Ividmeas))));
%bhat0=fft2(TrueImg);
MaxIter=5; %initialization

StopCond=10^-6*mean(mean(mean(Ividmeas)));
%parameters for line search
c=1/2;gamma=1/2;eps1=10^-6;


%%%%%%%%%%%%%%%%%%%%%%load the parameters into GPU if IsGPUprogram=1 %%%%%%%%%%%%%%%%%
if IsGPUprogram==1  
bhat0=gpuArray(bhat0);MaxIter=gpuArray(MaxIter);StopCond=gpuArray(StopCond);c=gpuArray(c);
gamma=gpuArray(gamma);eps1=gpuArray(eps1); 
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% scaled source FFT

EstSource=zeros(gather(Nx),gather(Ny));
EstSource(floor(Nx/2)+1,floor(Ny/2)+1)=1;

[zmax, zmax_n]=max(abs(z));%zmax is dummy here.
zmax=z(zmax_n);%find the most defocused position
ps_source=ps/zmax;

if IsGPUprogram==1
    ps_source=gpuArray(ps_source);
    EstSource=gpuArray(EstSource);
end
Source_fft_Nstack=scaledSourceFFT(Nx,Ny,ps,ps_source,EstSource,z);

if IsGPUprogram==1
    Source_fft_Nstack=gpuArray(Source_fft_Nstack);
end

%initialize with small z distance and coherent phase
Ividmeas1=gather(Ividmeas);
Source_fft_Nstack1=gather(Source_fft_Nstack);
HStack1=gather(HStack);

Nz_small=6;
Ividmeas=Ividmeas(:,:,nfocus-Nz_small:nfocus+Nz_small);
Source_fft_Nstack=Source_fft_Nstack(:,:,nfocus-Nz_small:nfocus+Nz_small);
HStack=HStack(:,:,nfocus-Nz_small:nfocus+Nz_small);


bhat0=IterativeOptimization(@CalErr,@CalGradient,bhat0,MaxIter,StopCond,c,gamma,eps1);

if IsGPUprogram==1
    Ividmeas=gpuArray(Ividmeas1);
    Source_fft_Nstack=gpuArray(Source_fft_Nstack1);
    HStack=gpuArray(HStack1);
    clear Ividemas1 Source_fft_Nstack1 HStack1;
else
    Ividmeas=Ividmeas1;
    Source_fft_Nstack=Source_fft_Nstack1;
    HStack=HStack1;
    clear Ividemas1 Source_fft_Nstack1 HStack1;
end

% 
% ahat0=ifft2(bhat0);
% ahat0=gather(ahat0);

%% iterations to esimate both source and phase
NIter=30;
tic
%parameter of source estiamtion

%initialize the small source
% Nx_smallsource=gather(Nx)-600; Ny_smallsource=gather(Ny)-600;
% cx_smallsource=floor(Nx_smallsource/2)+1; cy_smallsource=floor(Ny_smallsource/2)+1;
% 
% EstSource_small=zeros(Nx_smallsource,Ny_smallsource);
% EstSource=zeros(gather(Nx),gather(Ny));
% EstSource((cx-cx_smallsource+1):(cx+Nx_smallsource-cx_smallsource),(cy-cy_smallsource+1):(cy+Ny_smallsource-cy_smallsource))=EstSource_small;

EstSource=zeros(gather(Nx),gather(Ny));

maxiter_source=100; % maximum iteration when usin CG to solve the source
bw=100; % bandwith of the recovered frequency of the source. 

MaxIter2=2; %use phase and ampltitude update iteration

if IsGPUprogram==1
EstSource=gpuArray(EstSource);
maxiter_source=gpuArray(maxiter_source); bw=gpuArray(bw);
MaxIter2=gpuArray(MaxIter2);
end

figure;
for k=1:NIter

EstCohIntStack=abs(ifft2(bsxfun(@times,HStack,bhat0))).^2;%Fresnel propagation bhat0, inverse Fourier transform and take intensity

%x0=EstSource((cx-cx_smallsource+1):(cx+Nx_smallsource-cx_smallsource),(cy-cy_smallsource+1):(cy+Ny_smallsource-cy_smallsource)); 
%size of x0 can be smaller than the size of EstSource.

[EstSource]=DeconvSource_leastMeanSquare_FastApproximatebyCG(Ividmeas,EstCohIntStack,z,ps/ps_source,bw,EstSource,maxiter_source);
% [EstSource]=DeconvSource_leastMeanSquare_FastApproximatebyCG(gather(Ividmeas),gather(EstCohIntStack),gather(z),gather(ps/ps_source)...
%     ,gather(bw),gather(x0),gather(maxiter_source));

EstSource=real(EstSource); 
%EstSource=EstSource/(sum(sum(EstSource)));
toc

Source_fft_Nstack=scaledSourceFFT(Nx,Ny,ps,ps_source,EstSource,z); 
%Source_fft_Nstack=scaledSourceFFT(gather(Nx),gather(Ny),gather(ps),gather(ps_source),gather(EstSource),gather(z));

bhat0=IterativeOptimization(@CalErr,@CalGradient,bhat0,MaxIter2,StopCond,c,gamma,eps1);

subplot(2,2,1);
imagesc(EstSource);axis image;axis off; colormap gray; colorbar;title('Estimated illumination pattern');
% subplot(2,2,1)
% imagesc(abs(fft2(EstSource)).^(0.2));axis image;axis off; colormap gray; colorbar;title('FFT of estimated illumination pattern');
subplot(2,2,3);
imagesc(angle(gather(ifft2(bhat0))));
axis image;axis off; colormap gray; colorbar;title('Estimated phase');

subplot(2,2,4);
imagesc(abs(gather(fftshift(bhat0))).^(0.2));
axis image;axis off; colormap gray; colorbar;title('FFT of bhat0');

pause(0.1);

display(k);
toc

end

ahat0=ifft2(bhat0);
ahat0=gather(ahat0);

ahatOriginal=ahat0;
EstSourceOri=EstSource;
ahat0=Circlelowpassfilter_ZJS(ahatOriginal,1.5*NA_obj/lambda*ps*Nx,1.5*NA_obj/lambda*ps*Ny);

%ahat0phase=angle(ahat0);
%ahat0=ahat0*exp(-1i*mean(mean(angle(ahat0))));
%ahat0=ahat0*exp(1i*1.1);
% 
EstSource=Circlelowpassfilter_ZJS(EstSourceOri,50,50);
EstSource=real(EstSource);

%% show result

figure;
subplot(1,2,1)
imagesc(EstSource);axis image;axis off; colormap gray; colorbar;title('Estimated illumination pattern');
subplot(1,2,2)
imagesc(abs(fftshift(fft2(EstSource))).^(0.2));axis image;axis off; colormap gray; colorbar;title('FFT of estimated illumination pattern');

% figure;
% imagesc(EstSource);axis image;axis off; colormap gray; colorbar;title('Estimated illumination pattern');
% % 
% saveas(gcf,[filename 'EstimatedSource'],'fig');
% saveas(gcf,[filename 'EstimatedSource'],'tif');
% 
% figure;
% imagesc(Ividmeas(:,:,Nz));axis image;axis off;colormap gray
% title(sprintf('Measured Intensity at most defocus distance'));colorbar

figure;
imagesc(abs(ahat0.^2));
axis image;axis off;colormap gray
title('Estimated intensity');colorbar

% saveas(gcf,[filename 'EstimatedIntensityAtfocus'],'fig');
% saveas(gcf,[filename 'EstimatedIntensityAtfocus'],'tif');

figure;
imagesc(-angle(ahat0));
%imagesc(angle(ahat0));
axis image;axis off;colormap gray
title('Estimated phase');colorbar
% 
% saveas(gcf,[filename 'EsimatedPhase'],'fig');
% saveas(gcf,[filename 'EsimatedPhase'],'tif');

% figure;
% subplot(2,2,1);
% imagesc(fftshift(sum(abs(Source_fft_Nstack).*abs(imag(HStack)),3)));
% axis image;axis off; colormap gray; colorbar;title('Sum of F(S(z)) times imag(H)');
% 
% subplot(2,2,2);
% imagesc(1./fftshift(sum(abs(Source_fft_Nstack).*abs(imag(HStack)),3))); %,[1 10]
% axis image;axis off; colormap gray; colorbar;title('Invert Sum of F(S(z)) times imag(H)');
% 
% 
% subplot(2,2,3);
% imagesc(fftshift(sum(abs(imag(HStack)),3)));
% axis image;axis off; colormap gray; colorbar;title('Sum of imag(H)');
% 
% subplot(2,2,4);
% imagesc(1./fftshift(sum(abs(imag(HStack)),3)),[1 10]);
% axis image;axis off; colormap gray; colorbar;title('Invert Sum of imag(H)');

%save('-v7.3',savefn,'ahat0','ahatOriginal','EstSourceOri','EstSource','ps_source');

% figure;
% for nz=1:Nz
%     temp1=fftshift(gather(Source_fft_Nstack(:,:,nz)));
%     
%     subplot(1,2,1);
% imagesc(abs(temp1).^(0.2));
% axis image;axis off; colormap gray; colorbar;title(sprintf('Amplitude of fft of scaled source at %d',nz));
% 
%     subplot(1,2,2);
% imagesc(angle(temp1));
% axis image;axis off; colormap gray; colorbar;title(sprintf('phase of fft of scaled source at %d',nz));
% 
% pause(0.2);
%     
% end

% figure;
% for nz=1:Nz
%     imagesc(Ividmeas(:,:,nz));axis image;axis off;colormap gray
%     title(sprintf('Measured Intensity at %d',nz));colorbar
%     pause(0.2);
% end


