function [f]=CalErr(bhat0)
%Calculate error for the estimation bhat0

global Ividmeas HStack Source_fft_Nstack;

%bhat0=gpuArray(bhat0);

EstIntStack=abs(ifft2(bsxfun(@times,HStack,bhat0))).^2;%Fresnel propagation bhat0, inverse Fourier transform and take intensity
EstIntStack=ifft2(fft2(EstIntStack).*Source_fft_Nstack);
f=sum(sum(sum(abs(Ividmeas-EstIntStack).^2)));




% tic
% for nz=1:Nz
%     
%     bhat=HStack(:,:,nz).*bhat0;
%     ahat= Ft(bhat);
%     EstInt=abs(ahat.^2);
%     diff(:,:,nz)=Ividmeas(:,:,nz)-EstInt;
%     
%     % diff(:,:,nz)=Ividmeas(:,:,nz)-(abs(Ft(HStack(:,:,nz).*bhat0)).^2);
% 
% end
% toc




