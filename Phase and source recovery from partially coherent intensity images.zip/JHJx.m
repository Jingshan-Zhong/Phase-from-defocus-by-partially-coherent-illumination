function [y]=JHJx(bhat0,x)
% Calculate y=(J^H)J*x
% J matrix depends on bhat0


global Ividmeas HStack Source_fft_Nstack;

[Nx,Ny,Nz]=size(Ividmeas);

N=Nx*Ny;
%N=gpuArray(N);


ahatStack=ifft2(bsxfun(@times,HStack,bhat0));
KHHnx=ifft2(bsxfun(@times,HStack,x));

Temp1=2*real(conj(ahatStack).*KHHnx);
Temp1=ifft2(Source_fft_Nstack.*conj(Source_fft_Nstack).*fft2(Temp1));
Temp2=conj(HStack).*fft2(ahatStack.*Temp1);%/N is moved to the sum(Temp2,3)/N
y=sum(Temp2,3)/N;

%{
for nz=1:Nz
    
    %H= HStack(:,:,nz);
    %bhat=HStack(:,:,nz).*bhat0;
    ahat= ifft2(HStack(:,:,nz).*bhat0);
  
    
    KHHn= ifft2(HStack(:,:,nz).*x);
    
    Temp1=2*real(conj(ahat).*KHHn);
    
    Temp2=fft2(ahat.*Temp1)/N;
    Temp2=conj(HStack(:,:,nz)).*Temp2;

    
    y=y+Temp2;
    %yStack(:,:,nz)=Temp2;

  
end

%parpool('open','10');

y=gather(y);

%}

% for nz=1:Nz
%      y=y+yStack(:,:,nz);
% end

